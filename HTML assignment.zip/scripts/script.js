function validateEmail()
      {
         if( document.formname.firstName.value == "" &&
             document.formname.lastName.value == "" &&
             ... )
         {
            alert( "At least one field is required" );
            document.formname.username.focus();
            return false;
         }
       ...